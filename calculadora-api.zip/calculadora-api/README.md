# calculadora-api

API NestJS (TypeScript) sem banco de dados.

## Rodar
```bash
npm install
npm run start:dev
```

## Rotas (teste direto no navegador)
- http://localhost:3000/calculadora/somar?a=2&b=3 -> { "resultado": 5 }
- http://localhost:3000/calculadora/subtrair?a=10&b=4 -> { "resultado": 6 }
- http://localhost:3000/calculadora/multiplicar?a=3&b=5 -> { "resultado": 15 }
- http://localhost:3000/calculadora/dividir?a=8&b=2 -> { "resultado": 4 }
- http://localhost:3000/calculadora/dividir?a=8&b=0 -> 400 Bad Request

Parâmetros ausentes ou não numéricos também retornam 400.
