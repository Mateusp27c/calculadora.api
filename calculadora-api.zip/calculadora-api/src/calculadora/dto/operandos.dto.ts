import { Type } from 'class-transformer';
import { IsNumber } from 'class-validator';

export class OperandosDto {
  @Type(() => Number)
  @IsNumber({}, { message: 'a deve ser um número' })
  a: number;

  @Type(() => Number)
  @IsNumber({}, { message: 'b deve ser um número' })
  b: number;
}
