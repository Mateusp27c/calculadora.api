import { Controller, Get, Query } from '@nestjs/common';
import { CalculadoraService } from './calculadora.service';
import { OperandosDto } from './dto/operandos.dto';

@Controller('calculadora')
export class CalculadoraController {
  constructor(private readonly calculadora: CalculadoraService) {}

  @Get('somar')
  somar(@Query() { a, b }: OperandosDto) {
    return { resultado: this.calculadora.somar(a, b) };
  }

  @Get('subtrair')
  subtrair(@Query() { a, b }: OperandosDto) {
    return { resultado: this.calculadora.subtrair(a, b) };
  }

  @Get('multiplicar')
  multiplicar(@Query() { a, b }: OperandosDto) {
    return { resultado: this.calculadora.multiplicar(a, b) };
  }

  @Get('dividir')
  dividir(@Query() { a, b }: OperandosDto) {
    return { resultado: this.calculadora.dividir(a, b) };
  }
}
